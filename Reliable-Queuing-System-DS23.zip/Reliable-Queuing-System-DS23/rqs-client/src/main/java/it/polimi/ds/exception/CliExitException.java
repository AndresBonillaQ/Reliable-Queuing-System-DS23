package it.polimi.ds.exception;

public class CliExitException extends Exception{
}
