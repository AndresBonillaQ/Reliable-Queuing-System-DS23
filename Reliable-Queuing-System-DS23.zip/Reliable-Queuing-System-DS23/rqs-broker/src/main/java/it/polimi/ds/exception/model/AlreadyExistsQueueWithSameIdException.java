package it.polimi.ds.exception.model;

public class AlreadyExistsQueueWithSameIdException extends Exception{
}
