package it.polimi.ds.network2.utils.thread;

public interface IThreadsCommunication {

}
