package it.polimi.ds.message.response;

import java.io.Serializable;

public class CreateQueueResponse extends Response implements Serializable {
}
