package it.polimi.ds.old.broker.state;

public enum BrokerStateEnum {
    LEADER,
    FOLLOWER,
    CANDIDATE;
}
