package it.polimi.ds.exception.network;

public class FollowerNoLeaderHeartbeatException extends Exception{
}
