package it.polimi.ds.exception;

public class RequestNoManagedException extends Exception{
}
