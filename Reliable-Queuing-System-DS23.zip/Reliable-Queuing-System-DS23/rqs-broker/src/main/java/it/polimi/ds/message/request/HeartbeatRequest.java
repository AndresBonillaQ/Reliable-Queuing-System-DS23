package it.polimi.ds.message.request;

public class HeartbeatRequest {
    private final String heartbeat = "Hi, I'm the leader!";
}
