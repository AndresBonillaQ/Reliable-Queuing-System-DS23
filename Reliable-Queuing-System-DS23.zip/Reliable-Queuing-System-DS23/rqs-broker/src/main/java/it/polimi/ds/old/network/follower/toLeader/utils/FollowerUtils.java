package it.polimi.ds.old.network.follower.toLeader.utils;

import java.util.LinkedList;
import java.util.Queue;

public class FollowerUtils {
    public static final Queue<String> requestQueue = new LinkedList<>();

    private FollowerUtils(){}
}
