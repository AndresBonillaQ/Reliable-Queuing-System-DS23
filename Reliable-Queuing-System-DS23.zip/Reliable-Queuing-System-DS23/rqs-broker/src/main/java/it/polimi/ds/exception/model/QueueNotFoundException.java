package it.polimi.ds.exception.model;

public class QueueNotFoundException extends Exception{
}
