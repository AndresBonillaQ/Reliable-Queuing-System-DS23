package it.polimi.ds.message.response;

import java.io.Serializable;

public class AppendValueResponse extends Response implements Serializable {
}
