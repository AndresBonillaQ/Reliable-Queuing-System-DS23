# Reliable-Queuing-System-DS23
Project for the Distributed System course (2023-2024), Polimi
BELLA!!
